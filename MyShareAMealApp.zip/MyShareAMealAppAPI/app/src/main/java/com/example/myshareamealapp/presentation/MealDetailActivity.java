package com.example.myshareamealapp.presentation;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ShareCompat;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CenterCrop;
import com.example.myshareamealapp.R;
import com.squareup.picasso.Picasso;

// Meal Detail Screen
public class MealDetailActivity extends AppCompatActivity {
    private static final String LOG_TAG = MealDetailActivity.class.getSimpleName();

    // Member variables.
    private String mStatus;
    private Button mAanmeldenButton;
    private TextView mealsTitle;
    private TextView text_mealDescription;
    private TextView cooksName;
    private TextView cityName;
    private TextView text_price;
    private TextView text_servedDate;
    private TextView text_allergenicInfo;
    private CheckedTextView checked_text_option_vegan;
    private CheckedTextView checked_text_option_vega;
    private ImageView mealsImage;
    private ImageView cooksImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meal_detail);

        /* Really important, because if one doesn't work all don't work
         Speaking from experience, for some reason title worked,
         but the rest didn't.
         Turns out all i needed to do is add findViewById.
        het zijn altijd van die kleine dingen.*/
        mealsTitle = findViewById(R.id.text_mealName);
        text_mealDescription = findViewById(R.id.text_mealDescription);
        cooksName = findViewById(R.id.text_cookName);
        cityName = findViewById(R.id.text_cityName);
        text_price = findViewById(R.id.text_price);
        text_servedDate = findViewById(R.id.text_servedDate);
        text_allergenicInfo = findViewById(R.id.text_allergenicInfo);
        checked_text_option_vegan = findViewById(R.id.checked_text_option_vegan);
        checked_text_option_vega = findViewById(R.id.checked_text_option_vega);
        mealsImage = findViewById(R.id.image_meal);
        cooksImage = findViewById(R.id.image_cook);
        mAanmeldenButton = findViewById(R.id.button_aanmelden);

        Bundle extras = getIntent().getExtras();
        String title_string = extras.getString("title");
        String description_string = extras.getString("description");
        String image_string = extras.getString("image");
        String price_string = extras.getString("price");
        String served_string = extras.getString("date");
        String city_string = extras.getString("city");
        String cookFirstName_string = extras.getString("cookFirstName");
        String cookLastName_string = extras.getString("cookLastName");

        mealsTitle.setText(title_string);
        text_mealDescription.setText(description_string);
        Picasso.get().load(image_string).into(mealsImage);
        Glide.with(this).load("https://media.istockphoto.com/photos/cook-man-holding-plate-with-chicken-presenting-dish-in-kitchen-picture-id1198616328")
                .centerCrop()
                .transform(new CenterCrop())
                .into(this.cooksImage);

        text_price.setText(new StringBuilder().append("€ ").append(price_string).toString());
        text_servedDate.setText(new StringBuilder().append("Served on ").append(served_string).toString());
        cityName.setText(city_string);
        cooksName.setText(new StringBuilder().append(cookFirstName_string).append(" ").append(cookLastName_string).toString());

        if (savedInstanceState != null) {
            mStatus = savedInstanceState.getString("aanmelden_value");
            mAanmeldenButton.setText(mStatus);
        }
    }

    public void sendText(View view) {
        Log.i(LOG_TAG, "Successfully clicked on cook image!");
        String mimeType = "text/plain";
        ShareCompat.IntentBuilder
                .from(this)
                .setType(mimeType)
                .setChooserTitle(R.string.send_message_to)
                .startChooser();
    }

    public void toggleText(View view) {
        if (mAanmeldenButton.getText().equals(getString(R.string.aanmelden))) {
            Log.i(LOG_TAG, "Successfully added item!");
            mAanmeldenButton.setText(R.string.aangemeld);
        } else {
            Log.i(LOG_TAG, "Successfully removed item!");
            mAanmeldenButton.setText(R.string.aanmelden);
        }
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("aanmelden_value", (String) mAanmeldenButton.getText());
    }
}



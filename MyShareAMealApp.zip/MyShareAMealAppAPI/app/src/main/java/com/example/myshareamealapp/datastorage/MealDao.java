package com.example.myshareamealapp.datastorage;

import androidx.lifecycle.LiveData;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.example.myshareamealapp.domain.Meal;

import java.util.List;

public interface MealDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insert(Meal meal);

    @Query("DELETE FROM meal_table")
    void deleteAll();

    @Query("SELECT * from meal_table ORDER BY meal ASC")
    LiveData<List<Meal>> getAllMeals();

    @Query("SELECT * from meal_table LIMIT 1")
    Meal[] getAnyMeal();

    @Delete
    void deleteMeal(Meal meal);

}


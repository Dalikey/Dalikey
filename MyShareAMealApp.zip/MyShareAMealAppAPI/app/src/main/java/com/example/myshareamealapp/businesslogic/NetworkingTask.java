package com.example.myshareamealapp.businesslogic;

import android.os.AsyncTask;
import android.util.Log;

import com.example.myshareamealapp.domain.Meal;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class NetworkingTask extends AsyncTask<String, Void, List<Meal>> {

    private static String TAG = NetworkingTask.class.getSimpleName();
    private OnMealApiListener mListener;

    public NetworkingTask(OnMealApiListener listener) {
        this.mListener = listener;
    }

    @Override
    protected List<Meal> doInBackground(String... inputParams) {
        Log.i(TAG, "doInBackground called");

        String url = inputParams[0];
        Log.i(TAG, "inputParams = " + url);

        String response = null;
        response = doSendRequestToAPI(url);
        List<Meal> meals = createMealsFromJson(response);

        Log.i(TAG, "response = " + response);
        Log.i(TAG, "doInBackground finished");

        return meals;
    }

    private List<Meal> createMealsFromJson(String response) {

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        ArrayList<Meal> meals = new ArrayList<>();

        try {
            JSONObject jsonResponse = new JSONObject(response);
            JSONArray mealsList = jsonResponse.getJSONArray("result");
            for (int i = 0; i < mealsList.length(); i++) {
                JSONObject meal = mealsList.getJSONObject(i);

                String name = meal.getString("name");
                String description = meal.getString("description");
                String imageUrl = meal.getString("imageUrl");
                Date dateTime = dateFormat.parse(meal.getString("dateTime"));
                boolean isActive = meal.getBoolean("isActive");
                boolean isVega = meal.getBoolean("isVega");
                boolean isVegan = meal.getBoolean("isVegan");
                boolean isToTakeHome = meal.getBoolean("isToTakeHome");
                int maxAmountParticipants = meal.getInt("maxAmountOfParticipants");
                String price = meal.getString("price");

                JSONObject cook = meal.getJSONObject("cook");

                String city = cook.getString("city");
                String cookFirstName = cook.getString("firstName");
                String cookLastName = cook.getString("lastName");

                meals.add(new Meal(name, description, imageUrl, dateTime, isVega, isVegan, isToTakeHome, isActive, maxAmountParticipants, price, city, cookFirstName, cookLastName));
            }
        } catch (JSONException ex) {
            Log.e(TAG, "error: " + ex.getMessage());
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return meals;
    }

    @Override
    protected void onPostExecute(List<Meal> response) {
        Log.i(TAG, "onPostExecute called");
        mListener.onMealAvailable(response);
    }

    private String doSendRequestToAPI(String urlApiString) {

        InputStream inputStream = null;
        int responseCode = -1;

        // Het resultaat dat we gaan retourneren
        String response = "";

        // Maak verbinding met de urlApiString en haal het response op
        try {
            URL url = new URL(urlApiString);
            URLConnection urlConnection = url.openConnection();

            // Als het niet gelukt is om een URL connection op te zetten moeten we stoppen
            if (!(urlConnection instanceof HttpURLConnection)) {
                Log.e(TAG, "Niet gelukt om een URL connectie te maken!");
                return null;
            }

            // Initiëer de connectie en maak verbinding
            HttpURLConnection httpConnection = (HttpURLConnection) urlConnection;
            httpConnection.setAllowUserInteraction(false);
            httpConnection.setInstanceFollowRedirects(true);
            httpConnection.setRequestMethod("GET");
            httpConnection.connect();

            responseCode = httpConnection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                // De verbinding is gelukt. Lees hier de data.
                inputStream = httpConnection.getInputStream();
                response = getStringFromInputStream(inputStream);
                Log.i(TAG, "response = " + response);
            } else {
                // Verbinding lukte, maar de server geeft een foutcode
                Log.e(TAG, "Fout in responsCode: code = " + responseCode);
            }
        } catch (MalformedURLException e) {
            // De URL was niet correct geformuleerd.
            Log.e(TAG, "MalformedURLEx " + e.getMessage());
            return null;
        } catch (IOException e) {
            // Het lukte niet om verbinding te maken.
            Log.e(TAG, "IOException " + e.getMessage());
            return null;
        }
        // Hier hebben we een resultaat
        return response;
    }

    private static String getStringFromInputStream(InputStream is) {

        BufferedReader br = null;
        StringBuilder sb = new StringBuilder();

        String line;
        try {

            br = new BufferedReader(new InputStreamReader(is));
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    // Het lukte niet om verbinding te maken.
                    Log.e(TAG, "doInBackground IOException " + e.getMessage());
                }
            }
        }
        return sb.toString();
    }

    public interface OnMealApiListener {
        public void onMealAvailable(List<Meal> meals);
    }
}

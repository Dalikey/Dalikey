package com.example.myshareamealapp.presentation;


import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.myshareamealapp.R;
import com.example.myshareamealapp.domain.Meal;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

/***
 * The adapter class for the RecyclerView, contains the meals data.
 */
class MealAdapter extends RecyclerView.Adapter<MealAdapter.ViewHolder> implements Filterable {
    private static final String LOG_TAG = MealAdapter.class.getSimpleName();
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    // Member variables.
    private List<Meal> mMealsList;
    private List<Meal> mMealListFull;
    private Context mContext;

    /**
     * ViewHolder class that represents each row of data in the RecyclerView.
     */
    class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        // Member Variables for the TextViews
        private TextView mTitleText;
        private TextView mInfoText;
        private ImageView mMealsImage;

        /**
         * Constructor for the ViewHolder, used in onCreateViewHolder().
         *
         * @param itemView The rootview of the meal_list_item.xml layout file.
         */
        ViewHolder(View itemView) {
            super(itemView);

            //Initialize the views
            mTitleText = itemView.findViewById(R.id.title);
            mInfoText = itemView.findViewById(R.id.subTitle);
            mMealsImage = itemView.findViewById(R.id.image_meal);

            // Set the OnClickListener to the entire view.
            itemView.setOnClickListener(this);
        }

        void bindTo(Meal currentMeal) {
            // Populate the textviews with data.
            mTitleText.setText(currentMeal.getName());
            mInfoText.setText(new StringBuilder().append(dateFormat.format(currentMeal.getDateTime())).append(", ").append(currentMeal.getCity()).append(", € ").append(currentMeal.getPrice()).toString());
            Glide.with(mContext).load(currentMeal.getImageUrl()).into(mMealsImage);
        }

        @Override
        public void onClick(View view) {
            Log.i(LOG_TAG, "Successfully clicked on meal item!");

            Meal currentMeal = mMealsList.get(getAdapterPosition());
            Intent detailIntent = new Intent(mContext, MealDetailActivity.class);

            Bundle extras = new Bundle();
            extras.putString("description", currentMeal.getDescription());
            extras.putString("title", currentMeal.getName());
            extras.putString("image", currentMeal.getImageUrl());
            extras.putString("price", currentMeal.getPrice());
            extras.putString("date", dateFormat.format(currentMeal.getDateTime()));
            extras.putString("city", currentMeal.getCity());
            extras.putString("cookFirstName", currentMeal.getCookFirstName());
            extras.putString("cookLastName", currentMeal.getCookLastName());
            detailIntent.putExtras(extras);

            mContext.startActivity(detailIntent);
        }
    }

    /**
     * Constructor that passes in the meals data and the context.
     *
     * @param mealsList ArrayList containing the meals data.
     * @param context   Context of the application.
     */
    MealAdapter(Context context, List<Meal> mealsList) {
        this.mMealsList = mealsList;
        this.mContext = context;
    }


    /**
     * Required method for creating the viewholder objects.
     *
     * @param parent   The ViewGroup into which the new View will be added
     *                 after it is bound to an adapter position.
     * @param viewType The view type of the new View.
     * @return The newly created ViewHolder.
     */
    @Override
    public MealAdapter.ViewHolder onCreateViewHolder(
            ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(mContext).
                inflate(R.layout.meal_list_item, parent, false));
    }

    /**
     * Required method that binds the data to the viewholder.
     *
     * @param holder   The viewholder into which the data should be put.
     * @param position The adapter position.
     */
    @Override
    public void onBindViewHolder(MealAdapter.ViewHolder holder, int position) {
        // Get current meal.
        Meal currentMeal = mMealsList.get(position);

        // Populate the textviews with data.
        holder.bindTo(currentMeal);
    }

    /**
     * Required method for determining the size of the data set.
     *
     * @return Size of the data set.
     */
    @Override
    public int getItemCount() {
        return mMealsList.size();
    }

    public void setMealsData(List<Meal> mealsList) {
        mMealsList = (List<Meal>) mealsList;
        // Na 6 uren gevonden. Dit moet hier en niet in de Constructor.
        mMealListFull = new ArrayList<>(mealsList);
        notifyDataSetChanged();
    }

    @Override
    public Filter getFilter() {
        return mealFilter;
    }

    private Filter mealFilter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            List<Meal> filteredMeals = new ArrayList<>();

            if (constraint == null || constraint.length() == 0) {
                filteredMeals.addAll(mMealListFull);
            } else {
                String filterPattern = constraint.toString().toLowerCase().trim();
                for (Meal itemMeal : mMealListFull) {
                    if (itemMeal.getName().toLowerCase().contains(filterPattern)) {
                        filteredMeals.add(itemMeal);
                    }
                }

            }

            FilterResults results = new FilterResults();
            results.values = filteredMeals;
            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            mMealsList.clear();
            mMealsList.addAll((List) results.values);
            notifyDataSetChanged();
        }


    };
}

package com.example.myshareamealapp.presentation;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myshareamealapp.R;
import com.example.myshareamealapp.businesslogic.NetworkingTask;
import com.example.myshareamealapp.domain.Meal;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

// Meal List Screen
public class MealListActivity extends AppCompatActivity {

    public static final String EXTRA_MEAL = "Meal";
    private static final String LOG_TAG = MainActivity.class.getSimpleName();
    private final String ACTIVE_KEY = "active";
    public static String mApiUrl = "https://shareameal-api.herokuapp.com/api/meal";

    // Member variables.
    private RecyclerView mRecyclerView;
    private MealAdapter mAdapter;
    private ArrayList<Meal> mMealsList;
    private Button mAllButton;
    private Button mCakeButton;
    private Button mPokebowlButton;
    private SharedPreferences mPreferences;
    private String mSharedPrefFile =
            "com.example.android.myshareamealapp";
    private String mActive = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meal_list);

        // Set grid
        int gridColumnCount =
                getResources().getInteger(R.integer.grid_column_count);

        // Initialize the RecyclerView & other
        mRecyclerView = findViewById(R.id.recyclerViewMeals);
        mAllButton = findViewById(R.id.allFilter);
        mCakeButton = findViewById(R.id.cakeFilter);
        mPokebowlButton = findViewById(R.id.pokebowlFilter);
        mPreferences = getSharedPreferences(mSharedPrefFile, MODE_PRIVATE);

        // Initialize the ArrayList that will contain the data.
        mMealsList = new ArrayList<>();

        // Get the data.
        getMealApiData();

        // Initialize the adapter and set it to the RecyclerView.
        mAdapter = new MealAdapter(this, mMealsList);
        mRecyclerView.setAdapter(mAdapter);


        // Set the Layout Manager.
        mRecyclerView.setLayoutManager(new
                GridLayoutManager(this, gridColumnCount));
        int swipeDirs;
        if (gridColumnCount > 2) {
            swipeDirs = 0;
        } else {
            swipeDirs = ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT;
        }

        ItemTouchHelper helper = new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(ItemTouchHelper.LEFT |
                ItemTouchHelper.RIGHT |
                ItemTouchHelper.DOWN | ItemTouchHelper.UP,
                swipeDirs) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                int from = viewHolder.getAdapterPosition();
                int to = target.getAdapterPosition();
                Collections.swap(mMealsList, from, to);
                mAdapter.notifyItemMoved(from, to);
                return true;
            }


            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
            }
        });

        // Wait 1 second to load the data
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                // Do something after 1s = 1000ms
                // Restore preferences
                mActive = mPreferences.getString(ACTIVE_KEY, "");
                switch (mActive) {
                    case "Active C":
                        mAdapter.getFilter().filter("kap");

                        break;
                    case "Active PB":
                        mAdapter.getFilter().filter("pas");

                        break;
                    default:
                        mAdapter.getFilter().filter("");
                        break;
                }
            }
        }, 1000);

        helper.attachToRecyclerView(mRecyclerView);

    } // End of onCreate.

    // Creating a search menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);

        MenuItem searchItem = menu.findItem(R.id.action_search);
        SearchView searchView = (SearchView) searchItem.getActionView();

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                mAdapter.getFilter().filter(newText);
                return false;
            }
        });
        return super.onCreateOptionsMenu(menu);
    }


    private void getMealApiData() {
        NetworkingTask networkingTask = new NetworkingTask(new MealApiListener());
        String[] params = {mApiUrl};
        networkingTask.execute(params);
    }

    private class MealApiListener implements NetworkingTask.OnMealApiListener {
        @Override
        public void onMealAvailable(List<Meal> meals) {
            Log.i(LOG_TAG, "meals available = " + meals.toString());
//            Toast.makeText(MealListActivity.this, "Number of items read: " + meals.size(), Toast.LENGTH_LONG).show();
            mAdapter.setMealsData(meals);
        }
    }

    public void addMeal(View view) {
        mMealsList.add(0, new Meal("Fries", "3–2022, Netherlands, €4,99", "R.drawable.img_potato_wedges"));
        mAdapter.getFilter().filter("");
        Toast.makeText(this, "Number of items read: " + mMealsList.size(), Toast.LENGTH_LONG).show();

    }


    // Filters v------------------------------------------------------------------
    public void allFilterTapped(View view) {
        mAdapter.getFilter().filter("");
        mAllButton.setText(R.string.active_all);
        mActive = (String) mAllButton.getText();
        if (mCakeButton.getText().equals("Active C") || mPokebowlButton.getText().equals("Active PB")) {
            mCakeButton.setText(R.string.cake);
            mPokebowlButton.setText(R.string.pokebowl);
        }
    }

    public void cakeFilterTapped(View view) {
        mAdapter.getFilter().filter("kap");
        mCakeButton.setText(R.string.active_cake);
        mActive = (String) mCakeButton.getText();
        if (mPokebowlButton.getText().equals("Active PB") || mAllButton.getText().equals("Active All")) {
            mPokebowlButton.setText(R.string.pokebowl);
            mAllButton.setText(R.string.all);
        }
    }

    public void pokebowlFilterTapped(View view) {
        mAdapter.getFilter().filter("pas");

        mPokebowlButton.setText(R.string.active_pokebowl);
        mActive = (String) mPokebowlButton.getText();
        if (mCakeButton.getText().equals("Active C") || mAllButton.getText().equals("Active All")) {
            mCakeButton.setText(R.string.cake);
            mAllButton.setText(R.string.all);
        }
    }
    // Filters ^------------------------------------------------------------------


    // For Shared Preferences, Reads data back when the app is restarted.
    @Override
    protected void onPause() {
        super.onPause();
        SharedPreferences.Editor preferencesEditor = mPreferences.edit();
        preferencesEditor.putString(ACTIVE_KEY, mActive);
        preferencesEditor.apply();
    }
}

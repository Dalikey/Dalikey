package com.example.myshareamealapp.domain;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import com.google.gson.annotations.SerializedName;

import java.util.Date;

@Entity(tableName = "meal_table")
public class Meal {
    @PrimaryKey
    @NonNull
    @ColumnInfo(name = "meal")
    private String name;
    private String description;
    private String imageUrl;
    private Date dateTime;
    private String lijstVanIngredienten;
    @SerializedName("allergenes")
    private String lijstVanAllergeneninfo;
    private boolean isVega;
    private boolean isVegan;
    private boolean isToTakeHome;
    private boolean isActive;
    private int maxAmountParticipants;
    private String city;

    private String price;
    private String cookFirstName;
    private String cookLastName;

    public Meal(@NonNull String name, String description, String imageUrl, Date dateTime, String lijstVanIngrediënten, String lijstVanAllergeneninfo, boolean isVega, boolean isVegan, boolean isToTakeHome, boolean isActive, int maxAmountParticipants) {
        this.name = name;
        this.description = description;
        this.imageUrl = imageUrl;
        this.dateTime = dateTime;
        this.lijstVanIngredienten = lijstVanIngrediënten;
        this.lijstVanAllergeneninfo = lijstVanAllergeneninfo;
        this.isVega = isVega;
        this.isVegan = isVegan;
        this.isToTakeHome = isToTakeHome;
        this.isActive = isActive;
        this.maxAmountParticipants = maxAmountParticipants;
    }

    public Meal(String name, String description, String resourceId) {
        this.name = name;
        this.description = description;
        this.imageUrl = resourceId;
    }

    public Meal(String name, String description, String imageUrl, Date dateTime, boolean isVega, boolean isVegan, boolean isToTakeHome, boolean isActive, int maxAmountParticipants, String price, String city, String cookFirstName, String cookLastName) {
        this.name = name;
        this.description = description;
        this.imageUrl = imageUrl;
        this.dateTime = dateTime;
        this.isVega = isVega;
        this.isVegan = isVegan;
        this.isToTakeHome = isToTakeHome;
        this.isActive = isActive;
        this.maxAmountParticipants = maxAmountParticipants;
        this.price = price;
        this.city = city;
        this.cookFirstName = cookFirstName;
        this.cookLastName = cookLastName;
    }

    /**
     * Gets the name of the meal.
     *
     * @return The name of the meal.
     */
    public String getName() {
        return name;
    }

    /**
     * Gets the description of the meal.
     *
     * @return The description of the meal.
     */
    public String getDescription() {
        return description;
    }

    /**
     * Gets the imageUrl of the meal.
     *
     * @return The imageUrl of the meal.
     */
    public String getImageUrl() {
        return imageUrl;
    }

//    public String getImageUrl() {
//        return imageUrl;
//    }

    /**
     * Gets the dateTime of the meal.
     *
     * @return The dateTime of the meal.
     */
    public Date getDateTime() {
        return dateTime;
    }

    /**
     * Gets the list of ingredients of the meal.
     *
     * @return The list of ingredients of the meal.
     */
    public String getLijstVanIngredienten() {
        return lijstVanIngredienten;
    }

    /**
     * Gets the list of allergy information of the meal.
     *
     * @return The list of allergy information of the meal.
     */
    public String getLijstVanAllergeneninfo() {
        return lijstVanAllergeneninfo;
    }

    /**
     * Gets the isVega of the meal.
     *
     * @return The isVega of the meal.
     */
    public boolean isVega() {
        return isVega;
    }

    /**
     * Gets the isVegan of the meal.
     *
     * @return The isVegan of the meal.
     */
    public boolean isVegan() {
        return isVegan;
    }

    /**
     * Gets the isToTakeHome of the meal.
     *
     * @return The isToTakeHome of the meal.
     */
    public boolean isToTakeHome() {
        return isToTakeHome;
    }

    /**
     * Gets the isActive of the meal.
     *
     * @return The isActive of the meal.
     */
    public boolean isActive() {
        return isActive;
    }

    /**
     * Gets the maxAmountParticipants of the meal.
     *
     * @return The maxAmountParticipants of the meal.
     */
    public int getMaxAmountParticipants() {
        return maxAmountParticipants;
    }

    /**
     * Gets the price of the meal.
     *
     * @return The price of the meal.
     */
    public String getPrice() {
        return price;
    }

    public String getCity() {
        return city;
    }

    public String getCookFirstName() {
        return cookFirstName;
    }

    public String getCookLastName() {
        return cookLastName;
    }
}

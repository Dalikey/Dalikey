package com.example.myshareamealapp.presentation;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myshareamealapp.R;

// Login Screen
public class MainActivity extends AppCompatActivity {
    private static final String LOG_TAG =
            MainActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void launchListOfMeals(View view) {
        Log.i(LOG_TAG, "Successfully logged in!");

        Intent intent = new Intent(this, MealListActivity.class);
        startActivity(intent);

    }
}
